import numpy as np
import pandas as pd
import scipy.sparse as sp

from pipeline.consensus import cluster_consensus
from pipeline.xa_ratio import summarize_by_group, xa_ratio_per_cell


def _obs():
    rows = []
    for cl, lab, n in [("0", "T cell", 50), ("1", "B cell", 50), ("2", "Epithelial", 50)]:
        rows += [{"cluster": cl, "scanvi_label": lab, "scanvi_conf": 0.95}] * n
    return pd.DataFrame(rows)


def test_agree_and_discordant():
    llm = {"0": {"label": "T cell"}, "1": {"label": "Macrophage"}, "2": {"label": "Unknown"}}
    t = cluster_consensus(_obs(), llm).set_index("cluster")
    assert t.loc["0", "status"] == "agree" and t.loc["0", "consensus_label"] == "T cell"
    assert t.loc["1", "status"] == "discordant" and t.loc["1", "consensus_label"] == "needs_review"
    assert t.loc["2", "status"] == "scanvi_only" and t.loc["2", "consensus_label"] == "Epithelial"


def test_low_confidence_flagged():
    obs = _obs()
    obs["scanvi_conf"] = 0.3
    t = cluster_consensus(obs, {"0": {"label": "T cell"}}).set_index("cluster")
    assert t.loc["0", "status"] == "agree_low_confidence"
    assert t.loc["0", "consensus_label"] == "needs_review"


def test_xa_ratio_known_values():
    n_cells, n_x, n_a = 5, 20, 200
    X = np.zeros((n_cells, n_x + n_a))
    X[:, :n_x] = 1.0          # X genes expressed at 1.0
    X[:, n_x:] = 2.0          # autosomal genes expressed at 2.0
    chrom = ["X"] * n_x + ["1"] * (n_a // 2) + ["2"] * (n_a // 2)
    ratio = xa_ratio_per_cell(sp.csr_matrix(X), chrom)
    assert np.allclose(ratio, 0.5)


def test_xa_min_genes_gives_nan_and_summary():
    X = np.zeros((3, 30))
    X[:, :5] = 1.0
    X[:, 5:] = 2.0
    ratio = xa_ratio_per_cell(X, ["X"] * 5 + ["1"] * 25)
    assert np.isnan(ratio).all()
    s = summarize_by_group(np.array([0.5, 0.7, np.nan]), ["a", "a", "b"])
    assert list(s["cell_type"]) == ["a"] and s.loc[0, "n_cells"] == 2
